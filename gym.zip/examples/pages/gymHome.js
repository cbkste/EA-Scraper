var title = 'My Village - Village Gym';

var searchCommands = {

  VerifyonHomeScreen: function(client) {
    this.waitForElementVisible('@body',6000)
      .verify.title(title)
      return this;
  }
};

module.exports = {
  url: 'https://www.villagegym.co.uk/login/',
  commands: [searchCommands],
  elements: {
        body: { selector: '.my-account' },
  }
};
