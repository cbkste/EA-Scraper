var title = 'Class Timetable - Village Gym';

var searchCommands = {

  VerifyonTimetablePage: function(client) {
    this.waitForElementVisible('@body',6000)
      .verify.title(title)
      return this;
  },
  findTodaysClassId: function(client) {
    client.useXpath().click("//a[contains(@href,'#thursday')]");
    client.pause(2000);
    client.useCss();
    this.click('#SelectedClassTypeFilter option[value=Pilates]')

    return this;
  },

  getTextData: function(div) {
    this.getText(div, function(result) {
      console.log(result);
    });
  },

  findNextWeekClass: function(client, id) {
    client.useXpath()
    //client.click("//i[@class='lnr lnr-chevron-right']");
    client.pause(2000);

    client.assert.visible("//a[contains(@href,'#wednesday')]"); //#thursday
    client.click("//a[contains(@href,'#wednesday')]"); //#thursday
    client.pause(1000);

    client.useCss();
    //this.click('#SelectedClassTypeFilter option[value=Pilates]')
    client.pause(500);

    client.useXpath()

    client.assert.visible("//a[@id='booklink-"+client.globals.id+"']");
    client.click("//a[@id='booklink-"+client.globals.id+"']");
    //client.assert.visible("//a[@id='booklink-26513']");
    //client.click("//a[@id='booklink-26513']");
    return this;
  },

VerifyBookPage: function(client) {
    client.useCss();
    this.waitForElementVisible('@className', 3000)
        .assert.containsText('@className', "Kettlebells") //Pilates
    this.waitForElementVisible('@infoDate', 3000)
        .assert.containsText('@infoDate', "Wed")  //Thu
    this.waitForElementVisible('@infoTime', 3000)
        .assert.containsText('@infoTime', "07:00 - 07:30"); //09:30 - 10:15
    this.waitForElementVisible('@infoInstructor', 3000)
        .assert.containsText('@infoInstructor', "Kelley Angus"); //Angela Beckley
    this.waitForElementVisible('@infoLocation', 3000)
        .assert.containsText('@infoLocation', "Wellness Studio");

      return this;
  },

BookClass: function(client) {
      //this.click('@submitButton')
      return this;
  }
};

module.exports = {
  url: 'https://www.villagegym.co.uk/member/classtimetable/',
  commands: [searchCommands],
  elements: {
    body: { selector: '.my-account' },
    forwardSevenButton: { selector: 'subtmi[name=forwardSeven]' },
    available: { selector: '.notavailable' },
    className: {selector: 'p[id=className]'},
    infoDate: {selector: 'span[id=classDate]'},
    infoTime: {selector: 'span[id=classTime]'},
    infoInstructor: {selector: 'span[id=instructorName]'},
    infoLocation: {selector: 'span[id=studioName]'},
    submitButton: { selector: 'input[name=bookClass]' },
  }
};
