/* jshint expr: true */
module.exports = {
  'Book Gym Class' : function (client) {

    var loginPage = client.page.gymLogin();
    var homePage = client.page.gymHome();
    var classTimetablePage = client.page.gymClassTimetable();

    loginPage.navigate();

    loginPage.VerifyonLoginPage(client);
    loginPage.FillOutLoginInfo(client);
    loginPage.SubmitForm(client);

    homePage.VerifyonHomeScreen(client);

    classTimetablePage.navigate();
    classTimetablePage.VerifyonTimetablePage(client);
    classTimetablePage.findNextWeekClass(client);
    classTimetablePage.VerifyBookPage(client);
    classTimetablePage.BookClass(client);

    client.pause(1000);
    client.end();
  }
};
