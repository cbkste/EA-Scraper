module.exports = {
  command : function() {
    return this;
  }
};
