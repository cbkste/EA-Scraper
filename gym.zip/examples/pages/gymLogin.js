var title = 'Login - Village Gym';

var searchCommands = {

  VerifyonLoginPage: function(client) {
    this.waitForElementVisible('@body',6000)
      .verify.title(title)
      return this;
  },

  FillOutLoginInfo: function(client) {
    this.waitForElementVisible('@emailInput', 3000)
        .clearValue('@emailInput')
        .setValue('@emailInput', client.globals.email)

        .waitForElementVisible('@passwordInput', 3000)
        .clearValue('@passwordInput')
        .setValue('@passwordInput',client.globals.pass)

    return this;
  },

SubmitForm: function(client) {
      this.click('@submitButton')
      return this;
  }
};

module.exports = {
  url: 'https://www.villagegym.co.uk/login/',
  commands: [searchCommands],
  elements: {
    emailInput: { selector: 'input[name=EmailAddress]' },
    submitButton: { selector: 'input[name=loginButton]' },
    body: { selector: '.my-account' },
    passwordInput : { selector: 'input[name=Password]' },
  }
};
