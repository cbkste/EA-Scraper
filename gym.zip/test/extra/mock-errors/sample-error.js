throw new Error('An error in a user file');
